'use strict'

module.exports = {
  env: {
    node: true
  },
  parserOptions: {
    ecmaVersion: 2019
  }
}
