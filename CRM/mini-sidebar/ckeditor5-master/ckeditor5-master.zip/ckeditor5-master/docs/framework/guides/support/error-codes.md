---
category: framework-support
order: 60
---

# Error codes

CKEditor 5 Framework logs errors and warnings to the console. The following list contains more detailed descriptions of those issues.

{@errors}
