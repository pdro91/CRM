---
category: examples-builds
order: 10
classes: main__content--no-toc
---

# Classic editor

{@snippet build-classic-source}

{@link builds/guides/overview#classic-editor Classic editor} shows a boxed editing area with a toolbar, placed in a specific position on the page.

{@snippet examples/classic-editor}
