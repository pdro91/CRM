---
category: examples-builds
order: 30
classes: main__content--no-toc
---

# Balloon editor

{@link builds/guides/overview#balloon-editor Balloon editor} lets you create your content directly in its target location with the help of a balloon toolbar that appears next to the selected editable document element.

{@snippet examples/balloon-editor}
