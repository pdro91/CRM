Looking for CKEditor 5's source?
================================

This repository (https://github.com/ckeditor/ckeditor5) is the CKEditor 5's development environment. It centralizes various tools such as test runners, documentation and changelog generators, release scripts, etc.

The source code of the editor is split into multiple repositories, one for each of CKEditor 5 packages. Every package is developed at its own pace and in its own context. Check out the list of [CKEditor 5 packages and repositories](https://github.com/ckeditor/ckeditor5#packages).
