# Mathtype

Use "MathType" and "ChemType" buttons to insert formulas.

Note: There are some 404 HTTP error codes reported in the background until [2043](https://github.com/ckeditor/ckeditor5/issues/2043) is resolved.
